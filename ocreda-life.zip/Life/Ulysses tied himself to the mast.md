# Ulysses tied himself to the mast

In the Odyssey, Ulysses (Odysseus) has to sail past the Sirens, whose singing makes sailors steer onto the rocks. He wants to hear the song. So he has his crew plug their ears with wax and tie him to the mast, with orders to ignore anything he says until they're past.

He knew in advance that his future self would make a bad decision. So his calm self made it impossible.

Economists call this a commitment device. Modern versions:
- Save More Tomorrow, a program by Richard Thaler and Shlomo Benartzi. Employees agree now to save a portion of their future raises. Doesn't hurt today, and later the money goes to savings before they can miss it. Savings rates went up dramatically.
- Putting your alarm across the room.
- Paying for a class in advance so you show up.
- Deleting the app instead of trying to resist it.

The point isn't willpower. It's admitting you'll be weak later and setting it up while you're strong.
