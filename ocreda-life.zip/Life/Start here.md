# Start here

This is a sample vault. It belongs to a made-up person: a fifth-year PhD student who also writes a newsletter and is pitching a first book. They read constantly, highlight everything, save notes from books, papers, podcasts and late night rabbit holes. Then forget almost all of it.

Probably sounds familiar.

Here's the problem nobody talks about. Saving a note feels like keeping it. It isn't. Six months later you're stuck on something at work, and the exact answer is sitting in a note you wrote on a Sunday afternoon about Formula 1. You'll never search for it, because you don't remember it exists. You can't type a search for something you forgot.

That's the villain of this vault. Not bad notes. Forgotten ones.

It has beaten smarter people than us. Newton lost his own proof. Fleming's penicillin paper sat on a shelf for ten years while people died of infected scratches. Leonardo filled thousands of pages and kept scribbling a line asking if anything had ever been finished.

You don't need a better filing system. You need your old notes to show up on their own, at the moment they matter.

That's what Ocreda does. You write. While you write, it reads what you've saved before and brings back the notes that apply to this moment, quoting your own words so you can see why. Some solve the problem you're on. Some contradict you. Some extend what you're saying, or point at a pattern you didn't see.

How to try it with this vault:
1. Open a new note.
2. Write a few honest sentences about something you're stuck on right now. A chapter that won't start, an argument with a hole in it, a decision you keep going back and forth on. Don't make it pretty.
3. Watch the side panel.

The people in these notes are famous. The problem isn't. Every one of them had what they needed somewhere in their own past. Most of them found it by accident.

You won't have to.
