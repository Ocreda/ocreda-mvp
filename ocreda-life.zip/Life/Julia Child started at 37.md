# Julia Child started at 37

Julia Child didn't cook seriously until she was in her late 30s. She moved to Paris with her husband in 1948, had an incredible meal in Rouen (sole meunière), and decided to learn. She enrolled at Le Cordon Bleu in 1949.

She was bad at first. Tall, clumsy, in a class full of men training to be professional cooks.

She worked with two French women on a cookbook to teach French cooking to Americans. It took close to a decade. The first publisher rejected it as too long and complicated. Mastering the Art of French Cooking finally came out in 1961, when she was 49. Her TV show started two years later and she became famous after 50.

What I love about her book: the recipes explain why. Why the pan has to be hot. Why you dry the meat. Why you don't crowd the mushrooms. She was teaching you to understand, so you could fix things when they went wrong, not just follow steps.

She also made mistakes on live TV and kept going. Her line was basically: no apologies, nobody knows what it was supposed to look like.
