# No time to write this semester

Teaching two sections this semester. My calendar looks like a checkerboard: office hours at 10, meeting at 1, lab meeting at 3:30, a committee thing at 4:30. On paper I have "free" hours almost every day. In practice I write nothing.

An hour between a meeting and a class isn't writing time. By the time I've reread where I left off, it's time to go. So I answer email instead, and feel bad.

Weekends are the only time I get real work done, and I'm getting tired of that.

What I can actually change: I set my own office hours, I can move lab meeting to the afternoon if I ask, and I can say no to the committee thing.

What I haven't figured out: how to protect long blocks when every individual meeting looks so small on the calendar.
