# The drawer

My grandmother had a kitchen drawer. Rubber bands, a key to nothing, birthday candles, batteries that may or may not work, menus from restaurants that closed years ago. Everything in that drawer was saved on purpose. Nothing in it was ever found on purpose.

My notes app is that drawer.

I counted once. Around 1,400 notes. I could tell you what maybe 40 of them say.

The weird part is that saving felt productive every single time. Highlight, clip, add to notes, done. A little hit of having learned something. But learning isn't the save. Learning is the moment you use it, and the moment you need it is never the moment you saved it.

Things I know are in the drawer somewhere:
- a fix for the dense bread problem
- something about how a hospital copied a racing team
- a quote about stopping writing in the middle (Hemingway?)
- notes from that habits book I swore changed my life

I can't search for them because I don't remember the words I used. I barely remember they exist. Which is the whole problem. Search only works for things you already know you have.

What I actually want isn't a better drawer. It's for the drawer to open itself when I'm standing in front of it with the right problem.
