# Bread class: watch the dough, not the clock

Notes from the Saturday bread class at the community kitchen, spring 2025. The teacher was an old baker who'd run a bakery for 30 years. Grumpy, great.

What I wrote down:
- Fermentation runs on temperature, not time. Recipe times assume a warm kitchen, somewhere around 24-26C (75-78F). Every few degrees colder can make fermentation take much longer.
- So a recipe that says "bulk 4 hours" might need 6 or 7 in a cold kitchen. If you follow the clock, you'll underproof. Underproofed bread is dense, tight and gummy.
- Look for the signs instead: dough has grown noticeably (he said around half again in size for his recipe), it's domed, jiggly, has bubbles on the sides and top.
- If your kitchen is cold: use warmer water when mixing, put the dough in the oven with only the light on, or next to (not on) something warm.
- Change one thing at a time. Bakers who change everything learn nothing.

His line: the recipe is a suggestion, the dough is the boss.
