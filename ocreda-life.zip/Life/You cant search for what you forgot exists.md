# You can't search for what you forgot exists

Search assumes three things. You remember the thing exists. You remember roughly where it is. You remember the words you used.

Forgetting breaks the first one, and then the other two don't matter.

Every tool I've tried is good at the second and third. Folders, tags, links, full text search. They all help you find something you already know you're looking for.

But the best notes usually come from another part of your life. You wrote about bird beaks and the problem is train noise (this actually happened, the bullet train and the kingfisher). Nobody types "kingfisher" while redesigning a train.

So the question isn't "how do I find my notes." It's "how do my notes find me."

Vannevar Bush was basically asking this in 1945. Still mostly unanswered.
