# Mise en place

French kitchen term, roughly "everything in its place." Before service, every cook chops, measures and sets out everything they'll need, in the order they'll need it. When the orders start flying, they're not thinking, they're reaching.

It comes from the brigade system Auguste Escoffier organized in the late 1800s. Before that, big kitchens were chaos. He borrowed from the military: clear roles, a chain of command, every station with one job. The chef calls, everyone answers "Oui, chef." Sound familiar? It's a pit crew with knives.

Anthony Bourdain wrote that mise en place was basically his religion. Good cooks keep their station clean while they work because a messy station is a messy head.

What I took for home cooking: prep before you turn on the heat. I stopped burning garlic the week I started doing this.

What I suspect it's actually about: deciding in advance, when you're calm, so you don't have to decide later, when you're under pressure.
