# Sourdough attempt #6

Another brick. Dense crumb, tight, gummy in the middle, barely rose in the oven. Same as attempts 3, 4 and 5.

What I did, following the recipe exactly:
- starter fed the night before, it was bubbly
- mixed at 9am, stretch and folds every 30 min for 2 hours
- bulk fermentation 4 hours like the recipe says
- shaped, overnight in the fridge, baked at 250C in the dutch oven

The recipe has hundreds of good reviews so I don't think it's the recipe. I'm doing every step on time. I even bought a scale.

Possible culprits: flour? My oven? The starter not strong enough?

Kitchen is freezing now that it's fall, I've been baking in a sweater, not sure that matters.

I'm about to buy a new flour and a new starter and change everything at once, which I know is dumb.
