# GTD: open loops drain you

Notes from Getting Things Done by David Allen. Read it in 2023, the year I tried to fix my life with a label maker.

Core idea: every unfinished commitment in your head is an "open loop." Call the dentist, reply to Tom, figure out the garage. Each one quietly uses up attention. The mind is great at having ideas and terrible at holding them, so it keeps reminding you at the worst possible times.

His fix: capture everything outside your head. Get it into a trusted system and decide the very next physical action. Once your brain trusts the system, it stops nagging.

What I liked: the feeling after a full brain dump is real. Lighter.

What I didn't like: the system turned into a second job. Weekly reviews, contexts, lists of lists. I lasted about five weeks.

Main takeaway I want to keep: unfinished stuff isn't neutral. It costs something just by being unfinished.

Later found a study that made this click (Masicampo and Baumeister, 2011). People with an unfinished goal kept getting distracted by it, as expected. But people who simply wrote down a specific plan for when and how they'd finish it stopped getting distracted, even though the goal was still unfinished. The brain seems to accept "it's handled" as closure.

So it's not finished vs unfinished. It's unfinished with a plan (fine, even useful) vs unfinished without one (noise).
