# Atomic Habits notes

James Clear, Atomic Habits. Read January 2025, like everyone else in January.

The ideas I actually want to remember:

Two minute rule. When starting a new habit, shrink it until it takes two minutes. "Read before bed" becomes "read one page." "Go for a run" becomes "put on running shoes." The point is to master showing up before you try to improve. A habit has to exist before it can be optimized.

Identity. Don't aim for "run a marathon," aim for "I'm someone who runs." Every time you do it, even small, it's a vote for that identity.

Never miss twice. Missing once is an accident. Missing twice is the start of a new habit.

Make it easy, make it satisfying. If the habit feels bad every time, you will stop. Willpower doesn't beat a habit that feels like punishment.

Environment over motivation. Put the thing where you'll see it. Make the bad option harder to reach.

The British cycling story is in here too. Dave Brailsford's team improved hundreds of tiny things by about 1% each (better pillows, washing hands to avoid colds, heated shorts) and the gains added up.
