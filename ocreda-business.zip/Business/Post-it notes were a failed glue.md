# Post-it notes were a failed glue

1968. Spencer Silver, a chemist at 3M, is trying to make a super strong adhesive. He makes the opposite. A glue that sticks, but lightly, and peels off clean without leaving residue. It can be reused.

He thinks it's interesting, but nobody can think of what it's for. For years he goes around 3M presenting it in seminars. People called it a solution looking for a problem.

1974. Art Fry, another 3M scientist, sings in his church choir. His paper bookmarks keep falling out of his hymnal. Annoying, every Sunday. He remembers Silver's glue from one of those seminars and thinks: a bookmark that sticks but doesn't tear the page.

Then they figured out the bigger use: little notes you can stick anywhere. After some false starts, Post-it Notes launched nationally in 1980 and became one of the most used office products in the world.

Six years between the glue and the use. It needed a person carrying the old idea to bump into the right annoyance. Fry happened to have been in the right seminar and happened to remember it on a Sunday.
