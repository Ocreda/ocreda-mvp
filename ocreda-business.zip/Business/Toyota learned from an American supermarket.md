# Toyota learned from an American supermarket

Taiichi Ohno, the engineer behind the Toyota Production System, had a problem in the 1950s. Factories made huge piles of parts "just in case," and those piles cost money, took space and hid mistakes.

He'd heard about how American supermarkets worked, and later saw them himself. The store doesn't stock months of milk. A customer takes a carton, the shelf shows a gap, and the store refills exactly what was taken. The customer pulls, the store responds.

Ohno flipped the factory to work the same way. Each station only makes what the next station actually took. To signal it, they used cards, kanban, that travel with the parts. Empty bin plus a card means "make more of this." No card, no production.

This became just-in-time manufacturing, and half the world copied it from Toyota.

The best part: he got the idea for a car factory from people buying groceries. He saw a pattern in a completely ordinary place and recognized it as the answer to his problem.
