# Kodak invented the digital camera

1975. Steve Sasson, a young engineer at Kodak, builds the first digital camera. It's the size of a toaster, takes about 23 seconds to record one black and white picture at 0.01 megapixels onto a cassette tape, and needs a special setup to view it on a TV.

He shows it to management. As he tells the story, the reaction was roughly: that's cute, but don't tell anyone about it. Kodak made its money on film and printing. Why would anyone want to look at photos on a TV?

Kodak did keep working on digital and even held key patents. But the business never moved. It had the future in its own lab for decades. Kodak filed for bankruptcy in 2012.

The usual lesson is "innovate or die." The lesson I take is narrower. Kodak didn't forget the camera. It remembered it fine. What it couldn't do was let that old idea change what it was doing right now.

Remembering something and letting it change the work are different things.
