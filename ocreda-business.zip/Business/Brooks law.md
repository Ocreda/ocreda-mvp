# Brooks's law

Fred Brooks managed IBM's OS/360 project in the 1960s, one of the biggest software projects of its time. It went badly late. He wrote about what he learned in The Mythical Man-Month (1975), which programmers still quote.

The famous line: adding people to a late software project makes it later.

Why:
- New people need time to get up to speed, and the people who train them are the ones who were doing the work.
- Some tasks can't be split. His example: nine women can't make a baby in one month.
- Every person you add increases the number of people who need to talk to each other. Communication paths grow much faster than headcount. 5 people have 10 pairs. 10 people have 45.

The title is the joke. A "man-month" assumes people and months are interchangeable. They're not.

Applies way outside software. Any project where the work depends on shared understanding that lives in people's heads.
