# Is my book idea original enough?

An editor from a small press read my newsletter and asked if I'd ever thought about a book. I have. I've been thinking about it for two years. Now I have to write a proposal and every time I try I freeze on the same question: is this even new?

Everything in it comes from somewhere else. A bit from my research, a framework from a business book, examples from history, a lot of ideas I've written about in the newsletter already. When I list my sources it looks like I'm just remixing other people.

I keep reading "comparable titles" for the proposal and every one makes me feel like it's been done.

What I can't figure out:
- what makes a combination of old ideas actually new?
- how do I explain the angle so it doesn't sound like a summary of other books?

Proposal due August 1.
