# Maker's schedule, manager's schedule

Paul Graham essay from 2009. Short and it changed how I look at my calendar.

Two kinds of schedules:
- Manager's schedule: the day is cut into one hour blocks. You change what you're doing every hour. A meeting is just one more block.
- Maker's schedule: programmers, writers, designers need long uninterrupted chunks, at least half a day. You can't write well or build anything hard in one hour.

For a maker, a single meeting in the middle of the afternoon doesn't cost an hour. It can blow up the whole afternoon, because there's not enough time on either side to get into deep work.

His solution at Y Combinator: keep meetings at the end of the day, or cluster them. Protect the big blocks.

The problem is managers schedule meetings without seeing what they cost the people who have maker schedules. It looks like one hour on the calendar.
