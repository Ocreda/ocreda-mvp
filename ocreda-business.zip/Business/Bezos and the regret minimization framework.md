# Bezos and the regret minimization framework

1994. Jeff Bezos is 30, doing well at a hedge fund in New York, and wants to quit to start an online bookstore. His boss takes him on a long walk in Central Park and says it's a good idea, but a better idea for someone who doesn't already have a good job. Think about it for 48 hours.

How Bezos decided, by his own account: he imagined himself at 80, looking back on his life, and asked what he'd regret. He knew he wouldn't regret trying and failing at the internet. He'd regret never trying. A missed bonus wouldn't matter at 80.

So he left, drove across the country with his wife while writing the business plan, and started Amazon in a garage.

What I like as a tool: it gets you out of the short term noise. Most decisions feel huge because the cost is right here (a salary, an awkward conversation) and the benefit is far away. Projecting to 80 flips that.

What I'm wary of: it's a great story because it worked. Plenty of people quit on the same logic and it didn't.
