# Should I leave academia?

The question I keep circling. The newsletter has 3,000 subscribers now. The book proposal went out. A company reached out about a research job that pays almost double my stipend.

And the defense is eight months away. Five years of work.

The voice in my head: you're not going to get a tenure track job anyway, the market is brutal, why spend another year on a credential? Every month you wait is a month you could be building the writing career for real.

The other voice: you're so close. People who leave in the last year regret it. And 3,000 newsletter subscribers isn't a living.

Some days I'm writing the email to my advisor. Some days I feel embarrassed for even considering it.

Part of me just wants someone to tell me to go.
