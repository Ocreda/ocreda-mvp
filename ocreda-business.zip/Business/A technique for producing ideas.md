# A technique for producing ideas

James Webb Young, an advertising executive, wrote a tiny book in 1940 called A Technique for Producing Ideas. You can read it in an hour. People in advertising still pass it around.

His core claim: an idea is nothing more or less than a new combination of old elements. And the ability to make new combinations depends mostly on your ability to see relationships between things.

His five steps:
1. Gather raw material. Both the specific stuff about your problem and lots of general stuff about life and everything else.
2. Work it over. Look at the pieces together, try to fit them, feel stuck.
3. Drop it. Go do something else completely. Listen to music, go to the movies. Let the unconscious do its thing.
4. The idea shows up, usually when you're not looking for it. Shaving, in the bath, waking up.
5. Shape it. Take it out into the real world and let it get criticized and improved.

He says most people skip step 1 for general knowledge, so they have nothing to combine. Everything you've read is a potential piece of a future idea.

Same pattern as Poincaré. Work, let go, flash.
