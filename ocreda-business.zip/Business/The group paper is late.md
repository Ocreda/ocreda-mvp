# The group paper is late

Five authors, one paper, a journal deadline in six weeks. We're behind. Sections are written by different people and the handoffs are a mess: someone updates the data and the results section doesn't change, someone changes a term in the intro and nobody else uses it, two people rewrote the same paragraph last week without knowing.

The PI's solution today: bring in two more grad students to "help push it over the line."

Something about that feels wrong but I couldn't say why in the meeting. The hard part is the analysis section, and only Ana and I really understand what we did there. We already spend half our time explaining it to the others.

I have to send the PI a plan by Friday. Either I make the "more people" plan work, or I push back with something real. Also we have a 90 minute "sync" every Tuesday that mostly involves reading status updates out loud.
