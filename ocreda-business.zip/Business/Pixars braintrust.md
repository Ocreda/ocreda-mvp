# Pixar's Braintrust

From Ed Catmull, Creativity, Inc. (2014). Catmull co-founded Pixar.

His starting point: early on, all of Pixar's movies are bad. He calls them ugly babies. Toy Story 2 was so bad deep into production that they rebuilt most of it in a very short time.

The Braintrust is how they fix them. A group of experienced directors and storytellers watch the movie in progress every few months and give totally honest notes.

Rules that make it work:
- Notes are about the movie, not the person.
- The Braintrust has no authority. The director decides what to do with the notes. Taking away the power to force changes is what lets people be candid.
- They point out problems, they don't dictate solutions.

What I found striking: they treat candor as something you have to design for. It doesn't happen on its own, especially once there's a hierarchy. People tell the boss what the boss wants to hear.

Small group, regular, honest, no power. Closer to a pit crew review than a status meeting.
