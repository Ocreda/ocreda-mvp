# What a hospital learned from Ferrari's pit crew

Great Ormond Street Hospital in London, early 2000s. Two heart surgeons there, Martin Elliott and Allan Goldman, have a problem with the handover. After a child's heart surgery, the patient is moved from the operating room to intensive care, with all the machines, lines and information that go with them. It was messy. Too many people, nobody clearly in charge, information falling through the cracks.

After a long shift they were watching Formula 1 on TV and saw a pit stop. Around 20 people changing tires and refueling a car in seconds, without a word.

They thought: that's our handover, but done right.

So they went and studied it with the Ferrari and McLaren teams. What they took back:
- one person clearly in charge (in F1, the lollipop man)
- everyone has exactly one job and knows it
- the sequence is fixed and practiced, the same every time
- a short checklist, and nobody talks unless it's needed
- they rehearse

They redesigned the handover around this. Their published study found technical mistakes and missing information dropped noticeably.

The answer to a medical problem was on Sunday afternoon TV.
