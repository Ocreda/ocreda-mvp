# Amazon banned PowerPoint

In 2004, Jeff Bezos stopped PowerPoint presentations in Amazon's senior leadership meetings. Instead, whoever's presenting writes a memo, up to six pages, in full sentences.

Meetings start with everyone reading the memo in silence, for 20 or 30 minutes. Then they discuss.

Why he did it, from his own explanation: bullet points let you hide sloppy thinking. You can skip the connections between ideas. Writing full paragraphs forces you to understand which ideas matter more and how they relate.

The silent reading part matters too. Everyone actually reads it (no pretending you did at home). And people who are quieter get the same information as the loud ones before the arguing starts.

Side effect: meetings got shorter and more decisive, because the thinking was already done on paper.

I tried this once with a decision at work. Writing it out took me two hours and I changed my own mind halfway through.
