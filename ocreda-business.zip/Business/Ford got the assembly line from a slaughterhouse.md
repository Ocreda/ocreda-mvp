# Ford got the assembly line from a slaughterhouse

The moving assembly line at Ford's Highland Park plant started in 1913, and it changed manufacturing. Building a Model T chassis went from around twelve hours to about an hour and a half.

The idea didn't come from car people. Chicago meatpackers had been running "disassembly lines" for years. Carcasses hung from overhead trolleys and moved past workers, each of whom made the same cut over and over. One Ford engineer, William Klann, had seen this in Chicago and brought the idea back.

Ford ran it in reverse. Instead of taking an animal apart piece by piece, put a car together piece by piece. The worker stays, the work moves.

Ford himself said he didn't invent anything new, he just put together the discoveries of other people.

Copying from your own industry makes you a little better. Copying from a completely different industry is where the big jumps come from.
