# Phil Knight kept his day job

The founding of Nike is usually told like a bold leap. It wasn't. Phil Knight started importing Japanese running shoes in 1964, selling them out of the trunk of his car at track meets. For years he kept working as an accountant, including at Price Waterhouse, and taught accounting at Portland State University. The shoe company was the side thing until it could pay for itself. He went full time around 1969.

Same pattern with Sara Blakely. She kept her job selling fax machines door to door while she developed Spanx, for about two years. She wrote the patent herself to save money and only quit when the product was going to stores.

There's a study on this too, from 2014 (Raffiee and Feng). Founders who kept their day jobs while starting a business were substantially less likely to fail than those who quit to go all in.

The movies tell you to burn the boats. A lot of the real stories are people who built a lifeboat first.

Not saying it's always right. Just that "quit and jump" is not the only heroic way to do it.
