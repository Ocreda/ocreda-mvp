# Jobs took a calligraphy class

From Steve Jobs's Stanford commencement speech, 2005.

He dropped out of Reed College after one semester, but kept hanging around and sitting in on classes he found interesting. One was calligraphy. He learned about serif and sans serif typefaces, the spacing between letters, what makes good typography beautiful. No practical use for any of it in his life, he said.

Ten years later, designing the first Macintosh, it all came back. The Mac was the first computer with beautiful typography, multiple typefaces and proportional spacing. He said if he had never dropped in on that one course, the Mac would never have had them.

His point was that you can't connect the dots looking forward, only looking backward. You have to trust they'll connect somehow.

My only problem with this: the dots connected because Jobs happened to remember the class. How many dots do the rest of us have that never connect, just because we never think of them at the right moment?
