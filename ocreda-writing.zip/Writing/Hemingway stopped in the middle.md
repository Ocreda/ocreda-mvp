# Hemingway stopped in the middle

Hemingway's trick, which he repeated in a few places (an Esquire piece in 1935, and later in A Moveable Feast): always stop for the day while it's going well and you know what happens next. Don't write yourself empty.

His logic was that if you stop when you're stuck, tomorrow starts with being stuck. If you stop in the middle of a scene you're excited about, tomorrow starts with momentum. You sit down and you already know the next sentence.

He also said not to think about the story between sessions. Let the back of your mind work on it.

Roald Dahl did something similar. He said he never wrote himself out, he'd stop when he knew where it was going so he'd be eager to get back.

The counterintuitive part is that it feels wasteful. You're on a roll, why stop? Because the roll is what you're saving for tomorrow. You're leaving yourself a lit match instead of a cold stove.

Tried it twice in 2024. Worked both times, then I forgot about it.
