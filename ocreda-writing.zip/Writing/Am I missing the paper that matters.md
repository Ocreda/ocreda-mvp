# Am I missing the paper that matters?

Lit review panic. My committee meeting is in five weeks, and the thing I'm scared of is someone saying "how did you miss X?" and X being the paper that changes everything.

I've searched the databases every way I can think of. But search only finds what I already know to ask for. The paper that would really change my argument probably uses different words, comes from a different field, or is old enough that nobody cites it anymore.

Also, half my own reading notes from year one I don't remember. I know there are highlights in there from a book on organizational change, a whole folder on a method I dropped, things I clipped from blogs at 1am. Some of it is probably exactly relevant and I'd never think to look.

It's a weird feeling. The thing I'm afraid of missing might already be in my own notes.
