# My advisor says I ignore the counterevidence

Meeting with my advisor today. Her main comment on the chapter 2 draft: "Your argument is clean, too clean. Where are the cases that don't fit?"

She's right and I hate it. I know there were studies that cut against my main claim. I remember reading at least two. I didn't put them in. Not on purpose, exactly. When I sat down to write I just didn't think of them.

Looking at my notes now, almost everything I saved supports my position. I highlight what agrees with me. The stuff that bugged me, I read, felt uncomfortable, and moved on without writing anything down.

If I don't fix this, the defense will. Someone on the committee will bring up exactly the thing I left out.

I need to go back and find the evidence against me, and I need a habit so that this doesn't happen again in chapters 3 and 4.
