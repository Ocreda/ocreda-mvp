# Conference talk in three weeks

20 minute talk at the big conference in my field. First time on a main stage, not a poster.

I have 47 slides. That's too many, I know. Each one has bullet points, and when I practice I can tell I'm skipping the connections. Slide 12 says one thing, slide 13 says another, and I'm hoping the audience connects them because honestly I'm not sure I can explain how they connect.

My labmate watched me practice and said: "I understand every slide and I don't know what your argument is." Brutal. Fair.

The worst part is I do know my argument when I talk about it over coffee. Something about the slides breaks it into pieces.

I need to figure out what the one thing is, and build everything else around it. Three weeks.
