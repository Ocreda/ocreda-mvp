# Reviewer 2 destroyed the paper

Reviews came back on the first paper from my dissertation. Reviewer 1: minor revisions, nice. Reviewer 2: four pages. Calls the framing "naive," says the main finding is "unsurprising," lists eleven problems.

I spent a day being angry. Then a day being sure I'm bad at this. Today I read it again, and about seven of the eleven points are actually right. Annoyingly right.

What bugs me is that I could have caught most of this myself before submitting, if anyone had read the draft honestly. My labmates said "looks great." My advisor was traveling. The only person who told me the truth was an anonymous stranger, after it was too late.

For chapter 3 and the book I want a better way to get real feedback earlier, from people who'll actually be honest. Without it turning into everyone rewriting my stuff the way they'd do it.
