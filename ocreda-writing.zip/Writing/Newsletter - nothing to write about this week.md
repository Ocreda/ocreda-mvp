# Newsletter: nothing to write about this week

Issue #41 is due Thursday and I have nothing. Which is ridiculous, because I read about 20 things a week and save half of them.

The problem: when I sit down to pick a topic, my mind goes blank. I scroll through my saved articles and nothing jumps out, because I'm reading them cold, one by one, with no question in mind. Everything feels either too small or already said by someone else.

The issues people liked most were never planned. Issue #17 (the one that got shared everywhere) came from me noticing that something I'd read about restaurants explained something about my research. Two things from different parts of my life that turned out to be the same thing. I can't make that happen on purpose.

What I want: a way to stop starting from a blank list every week. Some kind of running set of questions I care about, so that when I read something new I already know what it might connect to.
