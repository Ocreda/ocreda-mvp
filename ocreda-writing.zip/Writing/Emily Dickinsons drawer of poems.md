# Emily Dickinson's drawer of poems

When Emily Dickinson died in 1886, her sister Lavinia found close to 1,800 poems among her things. Many were sewn into little handmade booklets, others written on scraps, envelope flaps, the backs of recipes.

Fewer than a dozen were published while she was alive, mostly without her name and edited to sound like what editors thought poems should sound like.

Lavinia had promised to burn Emily's letters, and she did. But she didn't burn the poems. She pushed to get them published. The first collection came out in 1890.

So one of the most important poets in American history was, while she lived, a woman with a drawer full of writing nobody read. The work existed. It just had nowhere to go.

What saved it wasn't more writing. It was one person who opened the drawer and decided it mattered.
