# Chapter 3 won't start

Fifth year. Chapters 1 and 2 are drafted. Chapter 3 is the one that holds the whole dissertation together and I've been "about to start" it since November.

Every morning goes the same. I open the file, reread what I wrote last time, fix commas for an hour, tell myself I'll start the real section after lunch. After lunch I answer emails. At night I lie in bed thinking about it, which is worse than writing it.

I don't think it's a knowledge problem. I've read everything. I have something like 300 notes on the sources for this chapter. It's that every session starts cold, from zero, and the blank part of the page is too big.

It also sits on me all week. Even on days I'm not supposed to be writing, it's there in the back of my head, like an unpaid bill.

My advisor wants a full draft by May. What I need is a way to start each morning already in motion, and a way to stop carrying it around 24 hours a day.
