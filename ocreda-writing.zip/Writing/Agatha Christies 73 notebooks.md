# Agatha Christie's 73 notebooks

Agatha Christie kept something like 73 notebooks over her career. Not neat. No system. She'd grab whichever was closest. Plot ideas next to shopping lists, possible murder methods next to notes about the garden. Sometimes she started from the back, or the middle.

A researcher, John Curran, went through all of them and found something great. Ideas jotted in one decade often show up in a book written ten or twenty years later. A poison, a trick with a will, a type of character. She'd flip through, find something she'd forgotten writing, and it became the center of a new book.

So the mess wasn't the problem. The messy notebooks were her idea bank for fifty years. But she had to physically flip through them. A good idea only came back if she happened to open the right notebook on the right day.

How many plots died in notebook 41 because she never reopened it?

(same thing with my chapter ideas, honestly)
