# J.K. Rowling and the delayed train

1990. J.K. Rowling is on a train from Manchester to London and it's delayed for about four hours. Out of nowhere, the idea of a boy who doesn't know he's a wizard walks into her head, almost fully formed. She didn't have a working pen and was too shy to ask anyone for one, so she just thought about it for the whole trip.

That evening she started writing. Then came five years of building the world before the first book was finished. Her notes were all over the place: scraps of paper, notebooks, napkins from cafés. She kept boxes of them. She worked out the plots of all seven books in advance, and one of her handwritten planning grids, the one for Order of the Phoenix, became famous. Columns for each subplot, rows for each chapter.

Things planted in book one paid off in book seven, because she'd written them down years before.

The first book was rejected by around twelve publishers. Bloomsbury took it in 1996, apparently after the chairman's eight year old daughter read the first chapter and demanded more.

The idea took four hours. Making it work took years of notes that had to come back at the right time.
