# Wallace remembered Malthus with a fever

1858, the Malay Archipelago. Alfred Russel Wallace is laid up with malaria. Shaking, feverish, nothing to do but think.

He'd been wondering for years why some animals survive and others don't. And lying there, something he'd read about twelve years earlier came back: Malthus, on population and the things that keep it in check.

The old reading showed up at the right moment and, as he remembered it, he had the idea of natural selection worked out within a couple of hours. He wrote it up and mailed it to... Charles Darwin.

Darwin got the letter in June 1858 and saw that someone had reached his idea independently. That finally pushed him to publish. On the Origin of Species came out the next year.

Same old book, two different men, years apart, both retrieving it exactly when their own problem was ripe.

Note to self: the reading wasn't wasted just because it took twelve years to pay off. It needed the right question to come along.
