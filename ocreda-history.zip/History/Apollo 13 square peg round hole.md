# Apollo 13: square peg, round hole

April 1970. An oxygen tank explodes on the way to the Moon. The three astronauts move into the lunar module, which was designed for two people for about two days, to use as a lifeboat.

New problem: carbon dioxide is building up. The lunar module's filters can't keep up. There are spare filters from the command module, but they're square, and the lunar module's sockets are round.

Engineers in Houston dump on a table exactly what the astronauts have on board. Plastic bags, cardboard covers from the flight manuals, a sock, hoses from the spacesuits, and duct tape. They have to figure out how to make the square filter work in the round system using only that, then explain it to the crew over the radio.

They do it. The astronauts build the adapter, the CO2 levels drop, and they get home.

What I take from it: the answer was already on board. They didn't need anything new. They needed someone to look at what they already had and see it differently, under pressure, fast.
