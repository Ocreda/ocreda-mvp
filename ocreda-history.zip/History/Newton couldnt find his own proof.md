# Newton couldn't find his own proof

August 1684. Edmond Halley rides up to Cambridge to ask Isaac Newton a question that has been bugging him, Wren and Hooke for months: if the sun pulls on the planets with a force that weakens with the square of the distance, what shape would their orbits be?

Newton answers right away. An ellipse. He'd already calculated it.

Halley, thrilled, asks to see the calculation. Newton goes through his papers and can't find it.

Think about that. The man who would write the most important science book in history had already solved its central problem, and he lost the paper. He promised to redo it and send it along.

He did. In November a short treatise arrived, De motu corporum in gyrum. Halley pushed him to keep going. Three years later, the Principia.

Two things I keep thinking about:
1. If Halley hadn't shown up with the right question at the right time, that proof might have stayed lost in a pile at Trinity. Somebody had to trigger the retrieval.
2. Losing the paper wasn't the disaster. Redoing it with fresh eyes made it bigger. The old work mattered because it got pulled back into a new moment.

Genius doesn't protect you from your own filing.
