# Darwin read Malthus for fun

September 1838. Darwin is 29, back from the Beagle, already convinced species change over time but missing the mechanism. He picks up Thomas Malthus's Essay on the Principle of Population. Not for work. By his own account, for amusement.

Malthus is writing about people and economics. Populations grow faster than the food supply, so there's always a struggle, and most don't make it.

Darwin reads that and it clicks. If more creatures are born than can survive, then any small advantage decides who lives. Good variations get kept, bad ones get lost. He had his theory.

An economics book about human poverty handed biology its biggest idea. He wasn't looking for it there. He couldn't have found it with a search, because he didn't know the answer lived in economics.

Then he sat on it for 20 years.
