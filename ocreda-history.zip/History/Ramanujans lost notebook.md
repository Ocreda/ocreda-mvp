# Ramanujan's lost notebook

Srinivasa Ramanujan, mostly self-taught, sends a letter packed with formulas to G.H. Hardy at Cambridge in 1913. Hardy figures it's either a fraud or a genius, and decides a fraud would have to be even more brilliant. Ramanujan comes to England, produces astonishing results, gets sick, goes home to India and dies in 1920. He was 32.

In his last year, very ill, he kept writing. Those pages went to England, passed between people, and ended up among the papers of a mathematician named Watson, which went to the library at Trinity College after Watson died.

Spring 1976. George Andrews, an American mathematician visiting Trinity, goes through those boxes and finds around a hundred pages of Ramanujan's last work. It had been sitting in a library for more than fifty years.

Mathematicians have been working through it for decades since. Some of the ideas later turned up in physics, including work on black holes, which Ramanujan had no way of knowing.

The detail I love: it wasn't destroyed. The library had it. It just wasn't findable by anyone who didn't already know to look.
