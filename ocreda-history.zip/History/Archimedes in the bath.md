# Archimedes in the bath

The story, as the Roman writer Vitruvius told it about two hundred years later. King Hiero of Syracuse had a gold crown made and suspected the goldsmith had mixed in cheaper silver. He asked Archimedes to find out without damaging the crown.

Archimedes was stuck. Then he got into a full bath, watched the water rise as his body went in, and realized the answer: an object pushes aside its own volume of water. Silver is lighter than gold, so a crown with silver in it would be bulkier and push aside more water than the same weight of pure gold. He was so excited he jumped out and ran home naked through the streets shouting "Eureka!" (I've found it).

Historians doubt it happened like that. But the reason everyone remembers it is that it feels true. The answer comes when you've stopped staring at the problem, while you're doing something ordinary, because the problem was loaded into your head and something in the world matched it.

The crown didn't solve itself. The bath did, because he'd already done the hard thinking.
