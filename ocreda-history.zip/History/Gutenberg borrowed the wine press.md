# Gutenberg borrowed the wine press

Johannes Gutenberg, Mainz, around 1450. Printing with carved wooden blocks already existed, and in East Asia movable type had been made centuries earlier. What Gutenberg put together for Europe was a system: metal type that could be cast quickly in a mold, an oil based ink that would stick to metal, and a press.

The press was the part he didn't invent. Screw presses had been used for a long time in the region for squeezing grapes and olives, and for pressing paper and cloth. He adapted it to push paper evenly onto inked type.

His background helped. He'd worked with metal, and at one point made small metal mirrors for pilgrims. So he combined metalworking, a winemaking tool and a goldsmith's knowledge of alloys.

The thing that changed history was a collage of things that already existed, from places that had nothing to do with books.
