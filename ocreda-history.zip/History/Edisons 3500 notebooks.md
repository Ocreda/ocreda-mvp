# Edison's 3,500 notebooks

Edison and his teams left behind roughly 3,500 notebooks. Millions of pages. Every experiment, failure, sketch, cost, half idea.

For the lightbulb filament they tried thousands of materials. Platinum, cotton thread, paper, fishing line, supposedly even hair from a staff member's beard. Eventually carbonized bamboo, which could burn for over a thousand hours.

The famous line about finding thousands of ways that don't work (probably not his exact words, but the idea is right) only works if you remember the thousands. The notebooks were how the lab avoided testing the same dead end twice. They were memory for a whole team.

What I keep thinking: even that system depended on someone remembering to go back and look. A notebook doesn't tap you on the shoulder. Edison could pay a lab full of assistants who knew where things were. Most of us are our own assistant, and we're bad at the job.
