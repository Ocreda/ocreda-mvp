# Leonardo: "tell me if anything was ever done"

Leonardo da Vinci left around 7,000 pages of notes that survive. Probably a lot more got lost. Flying machines, canal locks, anatomy, a mechanical knight, how light falls on a face, shopping lists, money he lent his assistant Salaì, who kept stealing from him.

Scattered through those pages, across different years, he tests his pen by writing the same line: dimmi se mai fu fatta cosa alcuna. Tell me if anything was ever done.

He had reasons to ask. Things he started and didn't finish:
- The Sforza horse. Meant to be the biggest bronze horse in the world. He made a full size clay model in 1493. The bronze set aside for it was sent off to make cannons in 1494. French soldiers later used the clay horse for target practice.
- The Adoration of the Magi, left unfinished when he moved to Milan.
- The Battle of Anghiari, a huge mural that started running because he experimented with the paint.
- Treatises on painting, on water, on anatomy. None published while he lived.

The anatomy one hurts most. His drawings of the heart were centuries ahead. Some of what he worked out about how heart valves close wasn't confirmed until modern imaging. Nobody could use it, because nobody could read it. It was in private notebooks, in mirror writing, in somebody's house.

The ideas were never the problem. The ideas were there. What he didn't have was a way for the right page to come back at the right moment, to him or to anyone else.
