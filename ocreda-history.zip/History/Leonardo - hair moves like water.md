# Leonardo: hair moves like water

One of my favorite pages. Leonardo is studying how water moves, how it pours, splits, curls back into itself. And he writes that hair does the same thing. Watch the surface of water, he says (paraphrasing), and see how it's like hair, which has two motions, one from its weight and one from the direction of its curl.

So his water drawings look like hair, and his angels' curls look like whirlpools. Same study.

This is what cross-domain thinking actually looks like up close. Not a grand theory. Just noticing that the thing you're drawing today behaves like the thing you drew last spring, and letting the old drawing teach the new one.

He could do it because both were in the same notebook, sometimes on the same page. He was his own search engine. That only works while you can hold the whole notebook in your head, and past a certain point not even Leonardo could.
