# Paul McCartney dreamed "Yesterday"

Mid 1960s. Paul McCartney wakes up in London with a complete melody in his head. He goes to the piano and plays it. It's beautiful, and that's exactly what worries him. It came too easily. He's convinced he must have heard it somewhere and is just remembering someone else's song.

So for weeks he plays it for people. Other musicians, friends, music industry people. Have you heard this before? Whose is it? Nobody knows it. While he's checking, he uses a joke working title, "Scrambled Eggs," as placeholder words.

Eventually he accepts it's his. "Yesterday" became one of the most recorded songs in history.

He was right to worry, though. There's a name for it: cryptomnesia, when a forgotten memory comes back and feels like a brand new idea. George Harrison lost a lawsuit in 1976 because a court found his song "My Sweet Lord" had subconsciously copied an older hit, "He's So Fine." The judge said he didn't do it on purpose. He'd just forgotten he'd heard it.

So your brain does surface old material on its own. It just strips off the label saying where it came from.
