# The plane that was too complicated to fly

October 30, 1935. Boeing's Model 299, the prototype that became the B-17 bomber, takes off for a demo for the Army Air Corps at Wright Field. It climbs, stalls, and crashes. Two of the crew die, including the pilot, Major Ployer Hill, one of the Army's most experienced test pilots.

The cause: he'd forgotten to release a lock on the elevator and rudder controls. A simple step, missed.

The press said it was too much plane for one man to fly. Way more steps than earlier planes.

The pilots didn't decide to train harder. The fix was almost embarrassingly simple. A checklist. One card for takeoff, flight, before landing, after landing. Things any pilot already knew.

With that checklist, B-17s went on to fly huge distances without an accident during testing, and the Army ordered thousands.

The lesson I keep getting from this: the problem wasn't knowledge. Hill knew about the lock. Knowing something and remembering it at the exact moment you need it are two different skills, and experts are not exempt from the second one.
