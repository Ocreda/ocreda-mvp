# As We May Think

Vannevar Bush, July 1945, in The Atlantic. Bush had run the US government's scientific research during the war. As the war ended, he wrote about what scientists should work on next.

His worry: humans were producing knowledge faster than anyone could use it. Important findings got lost in the pile. (He actually brings up Mendel, whose work was lost for a generation because the right people didn't see it.)

His idea was a desk he called the memex. It would store all your books, records and notes on microfilm, and let you call them up quickly. The key part wasn't the storage, it was what he called associative trails. He pointed out that the mind doesn't work like an index, alphabetically or by subject. It jumps from one item to the next by association, the way one thought suggests another. He wanted a machine that followed those connections.

People credit this essay as an early inspiration for hypertext and the web.

80 years later we have the storage, way more than he imagined. What we still mostly don't have is the second half: the thing that makes the right item come back on its own, at the moment you need it.
