# The O-ring memo

In July 1985, an engineer at Morton Thiokol named Roger Boisjoly wrote a memo about the rubber O-rings that sealed the joints of the space shuttle's solid rocket boosters. He'd seen damage on boosters recovered from earlier flights, worse when it had been cold. His memo warned that if this wasn't fixed, the result could be catastrophic.

January 27, 1986, the night before the Challenger launch. Forecast for Florida: well below freezing overnight, much colder than any previous launch. Boisjoly and other engineers argued against launching. There was a teleconference. Under pressure, managers overrode them.

The next morning Challenger broke apart 73 seconds after launch. All seven crew members died. The investigation found the cause was the O-ring seal failing in the cold.

The warning existed. It was on paper, months earlier, with photos. The knowledge was in the building. It lost to the schedule.

I keep this note because it's the clearest case I know of an organization that had the answer and didn't use it at the one moment it mattered.
