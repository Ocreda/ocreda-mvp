# The Wright brothers twisted a box

Everyone was trying to build planes with more power. The Wrights realized the real problem was control. How do you keep the thing balanced and turn it?

They watched birds, and noticed buzzards tilt the tips of their wings differently to roll and balance. Fine, but how do you do that with a wooden wing?

Summer 1899, in their bicycle shop in Dayton. Wilbur is talking to a customer while holding an empty cardboard box that had held a bicycle inner tube. He absentmindedly twists the box, and sees the top surface twist, one end up and one end down, while the box stays solid.

That's it. Twist the whole wing. They called it wing warping, and it's the ancestor of how planes still turn.

The bicycle business also mattered more than people think. They already understood balance (riding a bike is constant small corrections), light strong frames, and chains and sprockets for the propellers.

Birds for the idea, a cardboard box for the mechanism, bicycles for the know how. None of that was "aviation."
