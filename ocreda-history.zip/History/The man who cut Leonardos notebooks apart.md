# The man who cut Leonardo's notebooks apart

After Leonardo died in 1519, his notebooks went to his student Francesco Melzi, who looked after them for fifty years. When Melzi died, his son treated them like old paper. Pages walked out of the house.

Then a sculptor named Pompeo Leoni collected as many as he could and did something that sounds responsible. He organized them. He cut pages apart and pasted them into big albums, roughly by subject. Machines and technical drawings went into one enormous volume (now the Codex Atlanticus in Milan). A lot of the anatomy and nature drawings ended up in another collection (now at Windsor Castle).

Engineering here. Art and anatomy over there. Tidy.

The problem: Leonardo didn't think in categories. A page might have water swirling around a post right next to curls of hair, because to him they were the same problem. A gear next to a muscle. Leoni's scissors cut those neighbors apart. Scholars have spent centuries trying to work out which pages originally sat next to which.

I think about this every time I make a new folder.

Sorting by topic is how you find what you're looking for. It's also how you make sure you'll never stumble onto the connection between two things you'd never think to put together. Part of the value of Leonardo's pages was what was sitting next to what.
