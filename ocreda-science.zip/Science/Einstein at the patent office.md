# Einstein at the patent office

At 16, Einstein imagined chasing a beam of light. If you ran alongside it at the same speed, what would you see? A frozen wave? That seemed wrong, and it bothered him for years.

He couldn't get an academic job after university. In 1902 he started working as a clerk at the patent office in Bern, checking inventions. A lot of them were about electrical devices and keeping clocks in sync between train stations. He did physics on the side, in the evenings, and talked ideas through with a couple of friends.

1905, his "miracle year." Four papers, one of them special relativity. The light beam question from when he was 16 finally had its answer, about ten years later.

Two years after that, still at the patent office, he had what he called the happiest thought of his life: a person falling from a roof wouldn't feel their own weight. That became the start of general relativity.

What I notice: the old question never went away. It sat there for a decade until his daily work (clocks, signals, timing) gave him the pieces. The day job wasn't a distraction from the big idea. It fed it.
