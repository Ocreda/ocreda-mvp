# Semmelweis told doctors to wash their hands

Vienna General Hospital, 1840s. It had two maternity clinics. In the one run by doctors and medical students, far more mothers died of childbed fever than in the one run by midwives. Women begged to be put in the midwives' clinic.

Ignaz Semmelweis, a young doctor, couldn't stop thinking about the difference. Then a colleague cut his finger during an autopsy and died with symptoms that looked like childbed fever. Semmelweis realized the doctors were going straight from dissecting bodies to delivering babies, carrying something on their hands.

In 1847 he made them wash with a chlorine solution. Deaths in his clinic dropped dramatically, to around the level of the midwives' clinic.

The medical establishment mostly rejected it. The idea that gentlemen doctors' hands were killing patients was insulting, and he couldn't explain why it worked (germ theory came later, with Pasteur and Lister). He was also bad at persuading people and got angry. He died in an asylum in 1865.

The answer was there, written down, with numbers. People didn't use it because it contradicted what they believed. Sometimes the problem isn't forgetting the evidence. It's not wanting to remember it.
