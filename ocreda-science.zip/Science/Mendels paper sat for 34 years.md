# Mendel's paper sat for 34 years

Gregor Mendel, a monk in Brno, spent about eight years crossing pea plants. Tens of thousands of them. Tall vs short, wrinkled vs smooth, green vs yellow. He counted everything and found ratios, roughly 3 to 1, that kept showing up. In 1865 he presented it to the local natural history society. In 1866 it was printed in their journal.

Almost nobody noticed. It was cited only a handful of times over the next three decades. Darwin, who badly needed a theory of heredity for his own work and was alive and writing the whole time, never seems to have read it.

Mendel became abbot in 1868 and spent his time running the monastery and fighting a tax dispute. He died in 1884.

In 1900, three botanists working on heredity (de Vries, Correns and Tschermak) each went digging through old literature and each found Mendel. Basically at the same time. Genetics starts that year, 34 years after the paper came out.

What gets me: the answer existed. It was printed, it was in libraries. The person who needed it most was working on exactly that problem. Being written down is not the same as being found. The paper didn't need to be better. It needed to meet the right person at the right moment.
