# The bullet train that copied a bird

Japan, 1990s. The new Shinkansen trains are fast, but there's a problem. When a train shoots into a tunnel at high speed, it pushes a wave of air ahead of it, and when that wave leaves the other end it makes a loud boom. People living near tunnels complained, and noise rules were strict.

Eiji Nakatsu, an engineer at JR West, happened to be a serious birdwatcher. He thought about the kingfisher, which dives from the air into water, a much denser medium, and hardly makes a splash. Its long, wedge shaped beak lets it slice through.

So they modeled the nose of the train on a kingfisher's beak. The 500 Series came out in 1997 with a long pointed nose. The tunnel boom problem was solved, and the train used less electricity and ran faster.

He also used owl feathers (owls fly almost silently) to quiet the part on the roof that connects to the power lines, and a penguin's body shape for another part.

The answer was in his hobby. Not in engineering papers. You'd never find it by searching "train noise."
