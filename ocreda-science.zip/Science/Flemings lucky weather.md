# Fleming's lucky weather

A detail about the penicillin story that I didn't know. When later researchers tried to recreate Fleming's discovery by putting penicillin mold on a dish with bacteria, it often didn't work. The bacteria grew too fast and the mold never got a chance.

One reconstruction (by Ronald Hare, who had worked at St Mary's) looked at weather records for London that summer. There was a cool spell while Fleming was away, then it warmed up. The cool temperatures let the slow mold get established first, before the bacteria took off. Then the warm weather let the bacteria grow, everywhere except around the mold.

So the discovery depended on the temperature of the room. Too warm the whole time and there would have been nothing to see.

Temperature decides which living thing wins and how fast things grow. Fleming wasn't controlling it, the weather was.

Also a nice reminder that a lot of "bad luck" or "good luck" in an experiment is just a variable nobody's measuring.
