# Feynman's twelve favorite problems

From Gian-Carlo Rota, a mathematician who knew him. Rota said Feynman told him how he worked: keep about a dozen of your favorite problems always present in your mind. Most of the time they just sit there. But every time you hear or read a new trick or a new result, you test it against each of your twelve problems to see if it helps.

Every once in a while, there's a hit. And people say, how did he do it? He must be a genius.

That's the whole method. Keep your questions alive, and run everything new past them.

What I like is that it reverses how most of us take in information. We read something, file it under its own topic, move on. Feynman read something and immediately asked which of his problems it might solve. The new idea didn't go into a folder, it went into a conversation with his open questions.

Problem: holding twelve problems in your head is hard. Holding twelve problems plus everything you've ever read is impossible. Even for Feynman.
