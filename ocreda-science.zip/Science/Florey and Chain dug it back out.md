# Florey and Chain dug it back out

1938-39, Oxford. Howard Florey (pathologist) and Ernst Chain (biochemist) are surveying natural substances that kill bacteria. Chain goes through old papers and pulls out Fleming's 1929 penicillin paper. Ten years old, mostly ignored.

They do what Fleming couldn't. Norman Heatley on their team rigs a production setup out of bedpans, milk churns, bathtubs and a bookcase. In May 1940 they test it on infected mice. The treated mice live, the others die.

February 1941. Albert Alexander, an Oxford policeman, has a scratch (from a rose bush, in the usual telling) that has turned into a terrible infection. They give him penicillin. Within days he's dramatically better. Then they run out. They even recover penicillin from his urine to reuse it. It isn't enough. He relapses and dies.

By D-Day there's enough penicillin for the Allied troops. Fleming, Florey and Chain share the Nobel in 1945.

The difference between 1929 and 1940 wasn't a new discovery. It was someone pulling an old note into a new moment, with the right people around it. That's it. That's the whole gap.
