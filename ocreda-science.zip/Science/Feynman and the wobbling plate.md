# Feynman and the wobbling plate

Richard Feynman, after the war, at Cornell. He was burned out. Thought he was finished as a physicist. Every problem felt like a duty.

So he decided to just play. Do physics only for fun, only things that interested him, no matter how unimportant.

In the cafeteria someone threw a plate in the air as a joke. Feynman noticed the plate wobbled as it spun and the red Cornell logo on it went around at a different rate than the wobble. He worked out the math for the relationship just because it was fun.

He showed it to Hans Bethe, who asked what the use was. Feynman said there wasn't one, he was just having fun.

But working on how things rotate led him back into the physics of how electrons spin. And according to Feynman, the diagrams and the whole body of work he got the Nobel Prize for came from playing around with that plate.

When he stopped trying to be important, he did the important work. Play kept him close to the problem without the pressure that had made him freeze.
