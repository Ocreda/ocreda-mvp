# Gawande's surgical checklist

Atul Gawande, The Checklist Manifesto (2009). He's a surgeon, and he helped the World Health Organization design a 19 item checklist for surgery. Stuff like: confirm the patient and the procedure, everyone in the room says their name and role, check for allergies, check that the antibiotic was given, count the sponges.

Surgeons hated the idea at first. They're experts. Checklists are for beginners.

They tested it in eight hospitals around the world, rich and poor. Deaths dropped by around half. Major complications dropped by about a third.

The part I find most interesting: one of the biggest effects came from the introductions. Just going around and saying names made people more likely to speak up when something looked wrong. A nurse who's said her name out loud is more likely to say "wait."

Gawande's point is that we fail in two ways: not knowing enough (ignorance) and not using what we know (ineptitude, his word). Modern failure is mostly the second kind. We know. We just don't apply it at the right moment.

I underlined that twice.
