# Darwin's golden rule

From Darwin's autobiography. For years he followed what he called a golden rule: whenever he came across a published fact, an observation or a thought that went against his general results, he wrote a note about it immediately. Without fail.

Why? Because he'd noticed those facts slipped out of his memory much faster than the ones that agreed with him.

Read that again. Darwin, about as careful a thinker as has ever lived, caught his own memory editing the evidence. Not on purpose. It just quietly kept what agreed with him and let the rest go.

He said this was why hardly any objection was raised against his views that he hadn't already noticed and tried to answer.

Two lessons:
- Your memory is not neutral. It's on your side, which makes it a bad judge.
- The notes that disagree with you are the most valuable ones you have, and the most likely to be forgotten.

I don't do this. I save quotes that agree with me. My notes are a fan club.
