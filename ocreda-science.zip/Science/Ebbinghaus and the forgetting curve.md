# Ebbinghaus and the forgetting curve

Hermann Ebbinghaus, Germany, 1880s. He wanted to measure memory scientifically, which nobody had done. So he used himself as the subject. He memorized lists of nonsense syllables (things like "DAX," "BOK") so meaning couldn't help, and then tested how much he remembered after different amounts of time.

Published in 1885. The result is the forgetting curve. You lose most of new information fast, a big chunk within the first day, and then the loss slows down.

The second finding is the one that matters: each time you review, the curve gets flatter. You forget more slowly. And reviews spaced out over time work better than cramming them together.

So memory isn't a recording. It leaks unless something brings it back. And the best time to bring something back is right before you'd lose it.

This is the uncomfortable math behind my 1,400 notes. Without something bringing them back, almost all of them are past the steep part of the curve.
