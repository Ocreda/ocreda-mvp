# Fleming's mold sat on a shelf for ten years

September 1928. Alexander Fleming comes back from holiday to his famously messy lab at St Mary's in London. One of the dishes of staph bacteria he left out has mold growing on it, and around the mold the bacteria are dead. A clear ring.

He grows the mold, finds its juice kills a lot of dangerous bacteria, calls it penicillin, and publishes a paper in 1929.

And then, not much. It was hard to produce, unstable, and he couldn't purify it. He wasn't a chemist. He used it for a few lab things and moved on. The paper sat in the literature.

For about ten years, the most important medicine of the century existed in a journal. People kept dying of infected cuts, pneumonia, infections after childbirth. The answer had been written down.

The popular version gets this wrong. The discovery isn't the hero of the story. The retrieval is. Ten years later, two people in Oxford proved it.
