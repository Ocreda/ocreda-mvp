# Chance favors the prepared mind

Louis Pasteur, in a lecture in 1854. The line usually translated as: in the fields of observation, chance favors only the prepared mind.

He was talking about discoveries that look like accidents. They're not pure luck. The accident happens to lots of people. It only becomes a discovery for the person who already has the knowledge to recognize what they're seeing.

Plenty of people had probably seen mold kill bacteria on a dish and thrown it out. Fleming had been studying antibacterial substances for years, so he saw it.

Lots of people had picked burrs off their dogs. De Mestral was an engineer, so he looked at them under a microscope.

The flip side: being prepared means having the right knowledge available at the moment of the accident. Not somewhere in a notebook from five years ago. Available, right then.

Which is the hard part.
