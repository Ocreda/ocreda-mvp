# Velcro came from a dog walk

1941, the Swiss Alps. George de Mestral, an engineer, comes back from a hike with his dog and both of them are covered in burrs from burdock plants. Annoying. Most people would just pick them off.

He put one under a microscope instead. The burr was covered in tiny hooks that caught on anything with a loop: fur, the threads of his pants.

Hooks on one side, loops on the other. It took him years to figure out how to make it from nylon, and he patented it in the 1950s. He called it Velcro, from the French words for velvet and hook.

Nobody took it seriously at first, it looked cheap. Then NASA used it to keep things from floating around in space, and suddenly it was everywhere.

What I like: the irritating thing was the answer. The burrs were the problem on the walk and the solution in the workshop. Same object, different question.
