# The waiter who remembered every unpaid order

Berlin, 1920s. The psychologist Kurt Lewin is in a café with students and notices something about the waiter. He remembers every detail of the orders that haven't been paid yet. The moment a bill is settled, it's gone. He can't recall it at all.

His student Bluma Zeigarnik turned that into experiments in 1927. People were given simple tasks and interrupted in some of them. Afterward they remembered the interrupted tasks noticeably better than the finished ones.

That's the Zeigarnik effect. Unfinished things hold on. Your brain keeps them open, like a tab you can't close.

It explains a lot:
- why cliffhangers work
- why a half-done chore nags at you at 2am
- why stopping mid-sentence makes you want to come back (Hemingway figured this out without the science)

The finished task is a paid bill. Your mind lets it go.
